import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { OwnerService, ParkingLocation } from '../../services/owner.service';
import { NgbModal, NgbModalModule, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-owner-parking-locations',
  standalone: true,
  imports: [CommonModule, RouterModule, NgbModalModule],
  template: `
    <div class="container mt-4">
      <!-- Add a more prominent "Add Parking Location" button -->
      <div class="d-flex justify-content-end mb-3">
        <a [routerLink]="['/owner', userId, 'parking-locations', 'add']" class="btn btn-primary btn-lg">
          <i class="bi bi-plus-circle-fill me-2"></i> Add New Parking Location
        </a>
      </div>
      
      <div class="card">
        <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
          <h2 class="mb-0">My Parking Locations</h2>
          <a [routerLink]="['/owner', userId, 'parking-locations', 'add']" class="btn btn-light">
            <i class="bi bi-plus-circle"></i> Add New
          </a>
        </div>
        <div class="card-body">
          <div *ngIf="isLoading" class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
              <span class="visually-hidden">Loading...</span>
            </div>
            <p class="mt-2">Loading parking locations...</p>
          </div>
          
          <div *ngIf="errorMessage" class="alert alert-danger">{{ errorMessage }}</div>
          <div *ngIf="successMessage" class="alert alert-success">{{ successMessage }}</div>
          
          <div *ngIf="!isLoading && !errorMessage">
            <div *ngIf="parkingLocations.length === 0" class="text-center py-5">
              <p class="mb-3">You don't have any parking locations yet.</p>
              <a [routerLink]="['/owner', userId, 'parking-locations', 'add']" class="btn btn-primary">
                Add Your First Parking Location
              </a>
            </div>
            
            <div *ngIf="parkingLocations.length > 0" class="table-responsive">
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Capacity (2W/4W)</th>
                    <th>Rates (₹/hr)</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  <tr *ngFor="let location of parkingLocations">
                    <td>{{ location.name }}</td>
                    <td>{{ location.address }}, {{ location.city }}</td>
                    <td>{{ location.two_wheeler_capacity }}/{{ location.four_wheeler_capacity }}</td>
                    <td>{{ location.two_wheeler_price_per_hour }}/{{ location.four_wheeler_price_per_hour }}</td>
                    <td>
                      <span class="badge" [ngClass]="location.is_active ? 'bg-success' : 'bg-danger'">
                        {{ location.is_active ? 'Active' : 'Inactive' }}
                      </span>
                    </td>
                    <td>
                      <div class="d-flex gap-2">
                        <button 
                          (click)="editLocation(location)" 
                          class="btn btn-sm btn-outline-primary"
                          [disabled]="location.is_active">
                          Edit
                        </button>
                        <button (click)="toggleLocationStatus(location)" 
                                class="btn btn-sm" 
                                [ngClass]="location.is_active ? 'btn-outline-danger' : 'btn-outline-success'">
                          {{ location.is_active ? 'Deactivate' : 'Activate' }}
                        </button>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
          
          <div class="mt-3">
            <a [routerLink]="['/owner', userId, 'dashboard']" class="btn btn-secondary">Back to Dashboard</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Confirmation Modal for Active Location Edit Attempt -->
    <ng-template #deactivatePromptModal let-modal>
      <div class="modal-header bg-warning">
        <h5 class="modal-title">Location is Active</h5>
        <button type="button" class="btn-close" aria-label="Close" (click)="modal.dismiss()"></button>
      </div>
      <div class="modal-body">
        <p>You cannot edit an active parking location. Please deactivate it first to make changes.</p>
        <p>This helps avoid confusion for users who are viewing or booking the location.</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" (click)="modal.dismiss()">Cancel</button>
        <button type="button" class="btn btn-danger" (click)="deactivateAndEdit()">Deactivate and Edit</button>
      </div>
    </ng-template>
  `,
  styles: [`
    .badge {
      font-size: 0.9em;
      padding: 0.5em 0.75em;
    }
  `]
})
export class OwnerParkingLocationsComponent implements OnInit {
  userId: number | null = null;
  parkingLocations: ParkingLocation[] = [];
  isLoading = true;
  errorMessage = '';
  successMessage = '';
  selectedLocation: ParkingLocation | null = null;
  
  @ViewChild('deactivatePromptModal') deactivatePromptModal: any;
  
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private ownerService: OwnerService,
    private modalService: NgbModal
  ) {}
  
  ngOnInit(): void {
    // Try to get ID from route params first
    this.route.parent?.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.userId = +idParam;
      } else {
        // Fallback to currentUser
        const currentUser = this.authService.getCurrentUser();
        if (currentUser && currentUser.id) {
          this.userId = currentUser.id;
        }
      }
      
      // Load parking locations after getting user ID
      this.loadParkingLocations();
    });
  }
  
  loadParkingLocations(): void {
    this.isLoading = true;
    this.errorMessage = '';
    this.successMessage = '';
    
    this.ownerService.getParkingLocations().subscribe({
      next: (response) => {
        this.parkingLocations = response.parking_locations;
        this.isLoading = false;
      },
      error: (error) => {
        this.isLoading = false;
        if (error.error && error.error.message) {
          this.errorMessage = error.error.message;
        } else {
          this.errorMessage = 'Failed to load parking locations. Please try again.';
        }
      }
    });
  }
  
  toggleLocationStatus(location: ParkingLocation): void {
    this.ownerService.toggleParkingLocationStatus(location.id).subscribe({
      next: (updatedLocation) => {
        // Find and update the location in the array
        const index = this.parkingLocations.findIndex(loc => loc.id === location.id);
        if (index !== -1) {
          this.parkingLocations[index].is_active = !this.parkingLocations[index].is_active;
          
          this.successMessage = `Location "${location.name}" has been ${this.parkingLocations[index].is_active ? 'activated' : 'deactivated'}.`;
          
          // Auto-dismiss success message after 3 seconds
          setTimeout(() => {
            this.successMessage = '';
          }, 3000);
        }
      },
      error: (error) => {
        if (error.error && error.error.message) {
          this.errorMessage = error.error.message;
        } else {
          this.errorMessage = 'Failed to update location status. Please try again.';
        }
      }
    });
  }
  
  editLocation(location: ParkingLocation): void {
    if (location.is_active) {
      // If location is active, show warning modal
      this.selectedLocation = location;
      this.modalService.open(this.deactivatePromptModal);
    } else {
      // If location is inactive, proceed to edit page
      this.router.navigate(['/owner', this.userId, 'parking-locations', 'edit', location.id]);
    }
  }
  
  deactivateAndEdit(): void {
    if (this.selectedLocation) {
      this.ownerService.toggleParkingLocationStatus(this.selectedLocation.id).subscribe({
        next: () => {
          const locationId = this.selectedLocation?.id;
          
          // Update location status in the array
          if (this.selectedLocation) {
            const index = this.parkingLocations.findIndex(loc => loc.id === this.selectedLocation?.id);
            if (index !== -1) {
              this.parkingLocations[index].is_active = false;
            }
          }
          
          // Close modal
          this.modalService.dismissAll();
          
          // Navigate to edit page
          if (locationId && this.userId) {
            this.router.navigate(['/owner', this.userId, 'parking-locations', 'edit', locationId]);
          }
        },
        error: (error) => {
          this.modalService.dismissAll();
          if (error.error && error.error.message) {
            this.errorMessage = error.error.message;
          } else {
            this.errorMessage = 'Failed to deactivate location. Please try again.';
          }
        }
      });
    }
  }
} 