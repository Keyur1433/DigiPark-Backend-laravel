import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NgbDatepickerModule, NgbModal, NgbModalRef, NgbTimepickerModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../../../services/auth.service';
import { ParkingLocation, ParkingService } from '../../../services/parking.service';

@Component({
  selector: 'app-parking-locations',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    ReactiveFormsModule,
    NgbDatepickerModule,
    NgbTimepickerModule
  ],
  templateUrl: './parking-locations.component.html',
  styleUrls: ['./parking-locations.component.css']
})
export class ParkingLocationsComponent implements OnInit {
  parkingLocations: ParkingLocation[] = [];
  filteredLocations: ParkingLocation[] = [];
  searchForm: FormGroup;
  isLoading = false;
  error = '';
  view = 'grid'; // 'grid' or 'map'
  selectedLocation: ParkingLocation | null = null;
  showDetails = false;
  loginModalRef: NgbModalRef | null = null;
  isUserAuthenticated = false;

  constructor(
    private parkingService: ParkingService,
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private modalService: NgbModal
  ) {
    this.searchForm = this.fb.group({
      location: [''],
      date: [''],
      fromTime: [''],
      toTime: ['']
    });
  }

  ngOnInit(): void {
    this.loadParkingLocations();

    // Subscribe to authentication state
    this.authService.isAuthenticated.subscribe(isAuthenticated => {
      this.isUserAuthenticated = isAuthenticated;
    });
  }

  loadParkingLocations() {
    this.isLoading = true;
    this.error = '';

    this.parkingService.getParkingLocations().subscribe({
      next: (response: any) => {
        console.log('API response:', response);
        
        // Handle different response formats:
        // 1. If response is an array, use it directly
        // 2. If response is an object with data/locations property, extract that
        // 3. If response is empty or invalid, use empty array
        
        let locationData: ParkingLocation[] = [];
        
        if (Array.isArray(response)) {
          // Response is already an array
          locationData = response;
        } else if (response && typeof response === 'object') {
          // Response is an object, look for common property names that might contain the locations array
          if (response.data && Array.isArray(response.data)) {
            locationData = response.data;
          } else if (response.locations && Array.isArray(response.locations)) {
            locationData = response.locations;
          } else if (response.parking_locations && Array.isArray(response.parking_locations)) {
            locationData = response.parking_locations;
          } else if (response.results && Array.isArray(response.results)) {
            locationData = response.results;
          }
        }
        
        console.log('Processed location data:', locationData);
        this.parkingLocations = locationData;
        this.filteredLocations = [...locationData];
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error fetching parking locations', error);
        this.error = 'Failed to load parking locations. Please try again.';
        this.isLoading = false;
      }
    });
  }

  searchLocations() {
    if (this.searchForm.invalid) {
      return;
    }

    const searchCriteria = this.searchForm.value;

    if (searchCriteria.location && searchCriteria.location.trim() !== '') {
      this.isLoading = true;

      this.parkingService.searchParkingLocations(searchCriteria.location).subscribe({
        next: (locations) => {
          this.filteredLocations = locations;
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error searching parking locations', error);
          this.error = 'Failed to search parking locations. Please try again.';
          this.isLoading = false;
        }
      });
    } else {
      // If no search term, show all locations
      this.filteredLocations = [...this.parkingLocations];
    }
  }

  resetSearch() {
    this.searchForm.reset();
    this.filteredLocations = [...this.parkingLocations];
  }

  toggleView(viewType: 'grid' | 'map') {
    this.view = viewType;
  }

  viewLocationDetails(location: ParkingLocation) {
    // Navigate to location details page
    this.router.navigate(['/parking-locations', location.id]);
  }

  // Handle legacy code for details modal (in case it's still used)
  showLocationDetailsModal(location: ParkingLocation) {
    this.selectedLocation = location;
    this.showDetails = true;
  }

  closeDetails() {
    this.showDetails = false;
  }

  bookParking(location: ParkingLocation) {
    if (this.isUserAuthenticated) {
      console.log('User authenticated, navigating to booking page');
      this.router.navigate(['/parking-locations', location.id, 'booking']);
    } else {
      console.log('User not authenticated, showing login prompt');
      if (confirm('Please login first to book parking. Click OK to go to login page.')) {
        // Save intended location in session storage for redirect after login
        const redirectUrl = `/parking-locations/${location.id}/booking`;
        console.log('Setting redirectAfterLogin to:', redirectUrl);
        sessionStorage.setItem('redirectAfterLogin', redirectUrl);
        this.router.navigate(['/login']);
      }
    }
  }

  getAvailabilityClass(location: ParkingLocation): string {
    const availabilityPercentage = (location.available_spots / location.total_spots) * 100;
    if (availabilityPercentage > 50) {
      return 'available';
    } else if (availabilityPercentage > 20) {
      return 'limited';
    } else {
      return 'full';
    }
  }

  getAvailabilityText(location: ParkingLocation): string {
    const availabilityPercentage = (location.available_spots / location.total_spots) * 100;
    if (availabilityPercentage > 50) {
      return 'Available';
    } else if (availabilityPercentage > 20) {
      return 'Limited';
    } else {
      return 'Almost Full';
    }
  }

  formatRating(rating: number): string {
    return rating.toFixed(1);
  }
} 